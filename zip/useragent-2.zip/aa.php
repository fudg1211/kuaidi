<?php

sleep(10);

?>